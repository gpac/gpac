#ifndef hbbtvbrowserplugin_h
#define hbbtvbrowserplugin_h

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <npapi.h>
#include <nptypes.h>
#include <npfunctions.h>
#include <npruntime.h>
#include "hbbtvbrowserpluginapi.h"

#ifndef DEBUG
	#define DEBUG  true
	#define PROJECTNAME "HbbTVBrowserPlugin"
	#define TRACEINFO if (DEBUG) { printf("%s : call %s\n", PROJECTNAME, __FUNCTION__); }
	#define NOTIMPLEMENTED if (DEBUG) { printf("%s :  %s is NOT IMPLEMENTED : TODO \n", PROJECTNAME, __FUNCTION__); }
#endif

NPNetscapeFuncs* sBrowserFuncs;

char* booltostr(bool data);

NPError NP_Initialize(NPNetscapeFuncs* bFuncs, NPPluginFuncs* pFuncs);
NPError NP_Shutdown();
NPError NP_GetValue(void *instance, NPPVariable variable, void *value);
char*	NP_GetPluginVersion();
char*	NP_GetMIMEDescription();

NPError OIPF_NPP_New(NPMIMEType    pluginType, NPP instance, uint16_t mode, int16_t argc,   char *argn[], char *argv[], NPSavedData *saved);
NPError OIPF_NPP_Destroy(NPP instance, NPSavedData **save);
NPError OIPF_NPP_SetWindow(NPP instance, NPWindow *window);
NPError OIPF_NPP_HandleEvent(NPP instance, void* Event);
NPError OIPF_NPP_GetValue(NPP instance, NPPVariable variable, void *value);
NPError OIPF_NPP_SetValue(NPP instance, NPNVariable variable, void *value);
NPError OIPF_NPP_NewStream(NPP instance, NPMIMEType type, NPStream* stream, NPBool seekable, uint16_t* stype);

#endif
