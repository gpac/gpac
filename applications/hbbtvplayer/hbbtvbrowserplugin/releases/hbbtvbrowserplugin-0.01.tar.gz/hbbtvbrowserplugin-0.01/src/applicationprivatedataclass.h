#ifndef __APPLICATIONPRIVATEDATACLASS_H__
#define __APPLICATIONPRIVATEDATACLASS_H__

#include "hbbtvbrowserplugin.h"


NPClass* fillAPPPRIVDATApclass(void);

NPObject *  APPPRIVDATA_Allocate(NPP npp, NPClass *aClass);
void        APPPRIVDATA_Deallocate(NPObject *obj);
void        APPPRIVDATA_Invalidate(NPObject *obj);
bool        APPPRIVDATA_HasMethod(NPObject *obj, NPIdentifier name);
bool        APPPRIVDATA_Invoke(NPObject *obj, NPIdentifier name, const NPVariant *args, uint32_t argCount, NPVariant *result);
bool        APPPRIVDATA_InvokeDefault(NPObject *npobj, const NPVariant *args, uint32_t argCount, NPVariant *result);
bool        APPPRIVDATA_HasProperty(NPObject *obj, NPIdentifier name);
bool        APPPRIVDATA_GetProperty(NPObject *obj, NPIdentifier name, NPVariant *result);
bool        APPPRIVDATA_SetProperty(NPObject *obj, NPIdentifier name, const NPVariant *value);

bool        APPPRIVDATA_RemoveProperty(NPObject *npobj, NPIdentifier name);

bool        APPPRIVDATA_Enumerate(NPObject *npobj, NPIdentifier **value, uint32_t *count);


void APPPRIVDATA_Invoke_GetFreeMen(NPObject* obj,const NPVariant* args, uint32_t argCount);

#endif
