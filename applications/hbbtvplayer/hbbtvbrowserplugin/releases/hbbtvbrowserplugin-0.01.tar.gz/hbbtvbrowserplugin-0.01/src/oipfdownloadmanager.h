#ifndef __OIPFDOWNLOADMANAGER_H__
#define __OIPFDOWNLOADMANAGER_H__

#include "hbbtvbrowserplugin.h"


NPClass* fillODWLDMANpclass(void);

NPObject *  ODWLDMAN_Allocate(NPP npp, NPClass *aClass);
void        ODWLDMAN_Deallocate(NPObject *obj);
void        ODWLDMAN_Invalidate(NPObject *obj);
bool        ODWLDMAN_HasMethod(NPObject *obj, NPIdentifier name);
bool        ODWLDMAN_Invoke(NPObject *obj, NPIdentifier name, const NPVariant *args, uint32_t argCount, NPVariant *result);
bool        ODWLDMAN_InvokeDefault(NPObject *npobj, const NPVariant *args, uint32_t argCount, NPVariant *result);
bool        ODWLDMAN_HasProperty(NPObject *obj, NPIdentifier name);
bool        ODWLDMAN_GetProperty(NPObject *obj, NPIdentifier name, NPVariant *result);
bool        ODWLDMAN_SetProperty(NPObject *obj, NPIdentifier name, const NPVariant *value);

bool        ODWLDMAN_RemoveProperty(NPObject *npobj, NPIdentifier name);

bool        ODWLDMAN_Enumerate(NPObject *npobj, NPIdentifier **value, uint32_t *count);


void ODWLDMAN_Invoke_GetDownloads(NPObject* obj,const NPVariant* args, uint32_t argCount);
void ODWLDMAN_Invoke_Pause(NPObject* obj,const NPVariant* args, uint32_t argCount);
void ODWLDMAN_Invoke_Remove(NPObject* obj,const NPVariant* args, uint32_t argCount);
void ODWLDMAN_Invoke_Resume(NPObject* obj,const NPVariant* args, uint32_t argCount);

#endif
