#ifndef __DRMCONTROLINFOCOLLECTIONCLASS_H__
#define __DRMCONTROLINFOCOLLECTIONCLASS_H__

#include "hbbtvbrowserplugin.h"


#endif
