#ifndef __DOWNLOADCLASS_H__
#define __DOWNLOADCLASS_H__

#include "hbbtvbrowserplugin.h"

NPClass* fillDOWNLOADpclass(void);

NPObject *  DOWNLOAD_Allocate(NPP npp, NPClass *aClass);
void        DOWNLOAD_Deallocate(NPObject *obj);
void        DOWNLOAD_Invalidate(NPObject *obj);
bool        DOWNLOAD_HasMethod(NPObject *obj, NPIdentifier name);
bool        DOWNLOAD_Invoke(NPObject *obj, NPIdentifier name, const NPVariant *args, uint32_t argCount, NPVariant *result);
bool        DOWNLOAD_InvokeDefault(NPObject *npobj, const NPVariant *args, uint32_t argCount, NPVariant *result);
bool        DOWNLOAD_HasProperty(NPObject *obj, NPIdentifier name);
bool        DOWNLOAD_GetProperty(NPObject *obj, NPIdentifier name, NPVariant *result);
bool        DOWNLOAD_SetProperty(NPObject *obj, NPIdentifier name, const NPVariant *value);

bool        DOWNLOAD_RemoveProperty(NPObject *npobj, NPIdentifier name);

bool        DOWNLOAD_Enumerate(NPObject *npobj, NPIdentifier **value, uint32_t *count);


#endif
