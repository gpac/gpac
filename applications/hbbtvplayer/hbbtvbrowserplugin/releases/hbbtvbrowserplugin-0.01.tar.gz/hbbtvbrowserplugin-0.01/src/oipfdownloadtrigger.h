#ifndef __OIPFDOWNLOADTRIGGER_H__
#define __OIPFDOWNLOADTRIGGER_H__

#include "hbbtvbrowserplugin.h"



NPClass* fillODWLDTRGpclass(void);

NPObject *  ODWLDTRG_Allocate(NPP npp, NPClass *aClass);
void        ODWLDTRG_Deallocate(NPObject *obj);
void        ODWLDTRG_Invalidate(NPObject *obj);
bool        ODWLDTRG_HasMethod(NPObject *obj, NPIdentifier name);
bool        ODWLDTRG_Invoke(NPObject *obj, NPIdentifier name, const NPVariant *args, uint32_t argCount, NPVariant *result);
bool        ODWLDTRG_InvokeDefault(NPObject *npobj, const NPVariant *args, uint32_t argCount, NPVariant *result);
bool        ODWLDTRG_HasProperty(NPObject *obj, NPIdentifier name);
bool        ODWLDTRG_GetProperty(NPObject *obj, NPIdentifier name, NPVariant *result);
bool        ODWLDTRG_SetProperty(NPObject *obj, NPIdentifier name, const NPVariant *value);

bool        ODWLDTRG_RemoveProperty(NPObject *npobj, NPIdentifier name);

bool        ODWLDTRG_Enumerate(NPObject *npobj, NPIdentifier **value, uint32_t *count);

void ODWLDTRG_Invoke_registerDownload(NPObject* obj,const NPVariant* args, uint32_t argCount);
void ODWLDTRG_Invoke_registerDownloadURL(NPObject* obj,const NPVariant* args, uint32_t argCount);
#endif
