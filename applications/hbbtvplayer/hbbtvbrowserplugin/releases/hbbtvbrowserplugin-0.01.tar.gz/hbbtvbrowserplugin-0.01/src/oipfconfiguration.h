#ifndef    __OIPFCONFIGURATION_H__
#define    __OIPFCONFIGURATION_H__

#include "hbbtvbrowserplugin.h"

NPClass* fillOCFGpclass(void);

NPObject *  OCFG_Allocate(NPP npp, NPClass *aClass);
void        OCFG_Deallocate(NPObject *obj);
void        OCFG_Invalidate(NPObject *obj);
bool        OCFG_HasMethod(NPObject *obj, NPIdentifier name);
bool        OCFG_Invoke(NPObject *obj, NPIdentifier name, const NPVariant *args, uint32_t argCount, NPVariant *result);
bool        OCFG_InvokeDefault(NPObject *npobj, const NPVariant *args, uint32_t argCount, NPVariant *result);
bool        OCFG_HasProperty(NPObject *obj, NPIdentifier name);
bool        OCFG_GetProperty(NPObject *obj, NPIdentifier name, NPVariant *result);
bool        OCFG_SetProperty(NPObject *obj, NPIdentifier name, const NPVariant *value);

bool        OCFG_RemoveProperty(NPObject *npobj, NPIdentifier name);

bool        OCFG_Enumerate(NPObject *npobj, NPIdentifier **value, uint32_t *count);


#endif
