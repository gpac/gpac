#ifndef    __VIDEOBROADCAST_H__
#define    __VIDEOBROADCAST_H__

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <npapi.h>
#include <nptypes.h>
#include <npfunctions.h>
#include <npruntime.h>

#include "hbbtvbrowserplugin.h"

NPClass* fillVIDBRCpclass(void);

NPObject *  VIDBRC_Allocate(NPP npp, NPClass *aClass);
void        VIDBRC_Deallocate(NPObject *obj);
void        VIDBRC_Invalidate(NPObject *obj);
bool        VIDBRC_HasMethod(NPObject *obj, NPIdentifier name);
bool        VIDBRC_Invoke(NPObject *obj, NPIdentifier name, const NPVariant *args, uint32_t argCount, NPVariant *result);
bool        VIDBRC_InvokeDefault(NPObject *npobj, const NPVariant *args, uint32_t argCount, NPVariant *result);
bool        VIDBRC_HasProperty(NPObject *obj, NPIdentifier name);
bool        VIDBRC_GetProperty(NPObject *obj, NPIdentifier name, NPVariant *result);
bool        VIDBRC_SetProperty(NPObject *obj, NPIdentifier name, const NPVariant *value);
bool        VIDBRC_RemoveProperty(NPObject *npobj, NPIdentifier name);
bool        VIDBRC_Enumerate(NPObject *npobj, NPIdentifier **value, uint32_t *count);

void		VIDBRC_Invoke_setFullScreen(NPObject* obj,const NPVariant* args, uint32_t argCount);
void		VIDBRC_Invoke_bindToCurrentChannel(NPObject* obj,const NPVariant* args, uint32_t argCount);

#endif
