#ifndef __APPLICATIONCLASS_H__
#define __APPLICATIONCLASS_H__

#include "hbbtvbrowserplugin.h"


NPClass* fillAPPLICATIONpclass(void);

NPObject *  APPLICATION_Allocate(NPP npp, NPClass *aClass);
void        APPLICATION_Deallocate(NPObject *obj);
void        APPLICATION_Invalidate(NPObject *obj);
bool        APPLICATION_HasMethod(NPObject *obj, NPIdentifier name);
bool        APPLICATION_Invoke(NPObject *obj, NPIdentifier name, const NPVariant *args, uint32_t argCount, NPVariant *result);
bool        APPLICATION_InvokeDefault(NPObject *npobj, const NPVariant *args, uint32_t argCount, NPVariant *result);
bool        APPLICATION_HasProperty(NPObject *obj, NPIdentifier name);
bool        APPLICATION_GetProperty(NPObject *obj, NPIdentifier name, NPVariant *result);
bool        APPLICATION_SetProperty(NPObject *obj, NPIdentifier name, const NPVariant *value);

bool        APPLICATION_RemoveProperty(NPObject *npobj, NPIdentifier name);

bool        APPLICATION_Enumerate(NPObject *npobj, NPIdentifier **value, uint32_t *count);



void APPLICATION_Invoke_CreateApplication(NPObject* obj,const NPVariant* args, uint32_t argCount);
void APPLICATION_Invoke_DestroyApplication(NPObject* obj,const NPVariant* args, uint32_t argCount);
void APPLICATION_Invoke_Show(NPObject* obj,const NPVariant* args, uint32_t argCount);
void APPLICATION_Invoke_Hide(NPObject* obj,const NPVariant* args, uint32_t argCount);

#endif
