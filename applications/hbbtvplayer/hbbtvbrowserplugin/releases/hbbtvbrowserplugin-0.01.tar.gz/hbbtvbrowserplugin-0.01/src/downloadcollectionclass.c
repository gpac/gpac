
#include "downloadcollectionclass.h"


#define kDWLDCOLLECTION_ID_PROPERTY_LENGH					       	0
#define kDWLDCOLLECTION_NUM_PROPERTY_IDENTIFIERS                   1

#define kDWLDCOLLECTION_ID_METHOD_ITEM			               	    0
#define kDWLDCOLLECTION_NUM_METHOD_IDENTIFIERS                	    1

bool            v_bDWLDCOLLECTIONIdentifiersInitialized = false;

NPIdentifier    v_DWLDCOLLECTIONPropertyIdentifiers[kDWLDCOLLECTION_NUM_PROPERTY_IDENTIFIERS];
const NPUTF8 *  v_DWLDCOLLECTIONPropertyNames[kDWLDCOLLECTION_NUM_PROPERTY_IDENTIFIERS] = {
	"lengh"
    };

NPIdentifier    v_DWLDCOLLECTIONMethodIdentifiers[kDWLDCOLLECTION_NUM_METHOD_IDENTIFIERS];
const NPUTF8 *  v_DWLDCOLLECTIONMethodNames[kDWLDCOLLECTION_NUM_METHOD_IDENTIFIERS] = {
	"item"
	};

static  void    DWLDCOLLECTIONinitializeIdentifiers(void)
{
    sBrowserFuncs->getstringidentifiers( v_DWLDCOLLECTIONPropertyNames, kDWLDCOLLECTION_NUM_PROPERTY_IDENTIFIERS, v_DWLDCOLLECTIONPropertyIdentifiers );
    sBrowserFuncs->getstringidentifiers( v_DWLDCOLLECTIONMethodNames,   kDWLDCOLLECTION_NUM_METHOD_IDENTIFIERS,   v_DWLDCOLLECTIONMethodIdentifiers );
}


NPClass  stDWLDCOLLECTIONclass;
NPClass* pDWLDCOLLECTIONclass = NULL;

NPClass* fillDWLDCOLLECTIONpclass(void)
{
    TRACEINFO;
    if (pDWLDCOLLECTIONclass == NULL)
    {
        stDWLDCOLLECTIONclass.allocate          = DWLDCOLLECTION_Allocate;
        stDWLDCOLLECTIONclass.deallocate        = DWLDCOLLECTION_Deallocate;
        stDWLDCOLLECTIONclass.invalidate        = DWLDCOLLECTION_Invalidate;
        stDWLDCOLLECTIONclass.hasMethod         = DWLDCOLLECTION_HasMethod;
        stDWLDCOLLECTIONclass.invoke            = DWLDCOLLECTION_Invoke;
        stDWLDCOLLECTIONclass.invokeDefault     = DWLDCOLLECTION_InvokeDefault;
        stDWLDCOLLECTIONclass.hasProperty       = DWLDCOLLECTION_HasProperty;
        stDWLDCOLLECTIONclass.getProperty       = DWLDCOLLECTION_GetProperty;
        stDWLDCOLLECTIONclass.setProperty       = DWLDCOLLECTION_SetProperty;
        stDWLDCOLLECTIONclass.removeProperty    = DWLDCOLLECTION_RemoveProperty;
        stDWLDCOLLECTIONclass.enumerate         = DWLDCOLLECTION_Enumerate;
        pDWLDCOLLECTIONclass = &stDWLDCOLLECTIONclass;
    }

    return pDWLDCOLLECTIONclass;
}


NPObject *          DWLDCOLLECTION_Allocate(NPP npp, NPClass *theClass)
{
    TRACEINFO;

    NPObject* result;

    NPObject* newapplication = NULL;
    if (!v_bDWLDCOLLECTIONIdentifiersInitialized)
    {
        v_bDWLDCOLLECTIONIdentifiersInitialized = true;
        DWLDCOLLECTIONinitializeIdentifiers();
    }

    newapplication = malloc(sizeof(NPObject));

    result = newapplication;
    return result;
}


void        DWLDCOLLECTION_Deallocate(NPObject* obj)
{
    TRACEINFO;
    free(obj);
    return;
}

void        DWLDCOLLECTION_Invalidate(NPObject* obj)
{
    TRACEINFO;
    return;
}

bool        DWLDCOLLECTION_HasMethod(NPObject* obj, NPIdentifier name)
{
    TRACEINFO;
	bool result = false;
    int i = 0;
    NPUTF8* utf8methodname = (char*)sBrowserFuncs->utf8fromidentifier(name);
    while ((i < kDWLDCOLLECTION_NUM_METHOD_IDENTIFIERS) && (result == false))
    {
        if ( name == v_DWLDCOLLECTIONMethodIdentifiers[i] )
        {
            result= true;
        }
        i++;
    }
    printf("\tDWLDCOLLECTION has method \"%s\" : %s \n", utf8methodname, booltostr(result));
    return result;
}

bool        DWLDCOLLECTION_Invoke(NPObject* obj, NPIdentifier name, const NPVariant* args, uint32_t argCount, NPVariant* result)
{
    TRACEINFO;
    bool fctresult = false;
    if (name == v_DWLDCOLLECTIONMethodIdentifiers[kDWLDCOLLECTION_ID_METHOD_ITEM ])
    {
		DWLDCOLLECTION_Invoke_Item(obj, args, argCount);
		fctresult = true;
    }
    else
    {
    	printf("%s : method not found\n",__FUNCTION__);
    	fctresult = false;
    }
    return fctresult;

}

bool        DWLDCOLLECTION_InvokeDefault(NPObject *npobj, const NPVariant *args, uint32_t argCount, NPVariant *result)
{
    TRACEINFO;
    return true;
}

bool        DWLDCOLLECTION_HasProperty(NPObject* obj, NPIdentifier name)
{
    TRACEINFO;
    bool result = false;
    NPUTF8* utf8propertyname = (char*)sBrowserFuncs->utf8fromidentifier(name);

    int i = 0;
    while ((i < kDWLDCOLLECTION_NUM_PROPERTY_IDENTIFIERS) && (result == false))
    {
        if ( name == v_DWLDCOLLECTIONPropertyIdentifiers[i] )
        {
            result= true;
        }
        i++;
    }

    printf("\tDWLDCOLLECTION has property \"%s\" : %s \n", utf8propertyname, booltostr(result));
    return result;
}

bool        DWLDCOLLECTION_GetProperty(NPObject* obj, NPIdentifier name, NPVariant* result)
{
    TRACEINFO;
    return true;
}

bool        DWLDCOLLECTION_SetProperty(NPObject *obj, NPIdentifier name, const NPVariant *value)
{
    TRACEINFO;
    return true;
}

bool        DWLDCOLLECTION_RemoveProperty(NPObject *npobj, NPIdentifier name)
{
    TRACEINFO;
    return true;
}


bool        DWLDCOLLECTION_Enumerate(NPObject *npobj, NPIdentifier **value, uint32_t *count)
{
    TRACEINFO;
    return true;
}

/** implementation **/
void DWLDCOLLECTION_Invoke_Item(NPObject* obj,const NPVariant* args, uint32_t argCount)
{
	TRACEINFO;
	NOTIMPLEMENTED;
}
