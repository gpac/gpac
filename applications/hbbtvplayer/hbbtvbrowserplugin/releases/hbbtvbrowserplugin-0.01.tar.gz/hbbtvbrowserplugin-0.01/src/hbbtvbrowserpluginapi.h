#ifndef hbbtvbrowserpluginapi_h
#define hbbtvbrowserpluginapi_h

//void OnSetWindow(int x, int y, int width, int height);

///Callbacks for videobroadcast

void OnVIDBRC_SetFullScreen(int);

#endif
