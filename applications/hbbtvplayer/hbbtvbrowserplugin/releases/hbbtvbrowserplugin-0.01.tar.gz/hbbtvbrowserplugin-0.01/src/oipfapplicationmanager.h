#ifndef    __OIPFAPPLICATIONMANAGER_H__
#define    __OIPFAPPLICATIONMANAGER_H__

#include "hbbtvbrowserplugin.h"


NPClass* fillOAMpclass(void);

NPObject *  OAM_Allocate(NPP npp, NPClass *aClass);
void        OAM_Deallocate(NPObject *obj);
void        OAM_Invalidate(NPObject *obj);
bool        OAM_HasMethod(NPObject *obj, NPIdentifier name);
bool        OAM_Invoke(NPObject *obj, NPIdentifier name, const NPVariant *args, uint32_t argCount, NPVariant *result);
bool        OAM_InvokeDefault(NPObject *npobj, const NPVariant *args, uint32_t argCount, NPVariant *result);
bool        OAM_HasProperty(NPObject *obj, NPIdentifier name);
bool        OAM_GetProperty(NPObject *obj, NPIdentifier name, NPVariant *result);
bool        OAM_SetProperty(NPObject *obj, NPIdentifier name, const NPVariant *value);
bool        OAM_RemoveProperty(NPObject *npobj, NPIdentifier name);
bool        OAM_Enumerate(NPObject *npobj, NPIdentifier **value, uint32_t *count);

void		OAM_ObjectMain_Invoke_GetOwnerApplication(NPObject* obj,const NPVariant* args, uint32_t argCount);

/*
typedef struct{
	NPObject	headear;
	NPP			npp;
	NPObject*	onLowMemory;
	NPObject* 	ownerApplication;
	NPObject* 	newApplication;
} OAM_ObjectMain;
*/


#endif
